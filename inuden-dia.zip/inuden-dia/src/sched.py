from net import *
RANK={"快速":3,"急行":2,"各停":1,"回送":2}
H_DEP=90; H_ARR=90; PAD=30; SPAD=30
class Train:
    def __init__(s,id,kind,o,d,dep,cars=4,label=None,note=""):
        s.id=id;s.kind=kind;s.o=o;s.d=d;s.dep0=dep;s.cars=cars;s.hold={};s.xstop=set();s.note=note
        s.route=route(o,d); s.label=label or kind
        s.dir=s._dir(); s.times=None
    def _dir(s):
        r=s.route
        a,b=r[0],r[1]
        if a in MN and b in MN: return "D" if MN.index(b)>MN.index(a) else "U"
        return "D" if HN.index(b)>HN.index(a) else "U"
    def stops(s):
        st=STOPS[s.kind]
        out=[]
        for x in s.route:
            if x==s.o or x==s.d or st is None or x in st or x in s.xstop or x in s.hold: out.append(x)
        return out
    def is_stop(s,x):
        st=STOPS[s.kind]
        return x==s.o or x==s.d or st is None or x in st
    def compute(s):
        r=s.route; sl=s.stops(); T={}
        t=s.dep0+s.hold.get(s.o,0); T[s.o]=[None,t,True]
        for a,b in zip(sl,sl[1:]):
            i,j=r.index(a),r.index(b)
            tot,ps=seg(tuple(r[i:j+1]))
            dep=T[a][1]
            for x,p in zip(r[i+1:j],ps): T[x]=[dep+p,dep+p,False]
            arr=dep+tot
            if b==s.d: T[b]=[arr,None,True]
            else:
                dw=(dwell(b) if s.is_stop(b) else 0)+s.hold.get(b,0)
                T[b]=[arr,arr+dw,True]
        s.times=T; return T
    def arr(s,x): v=s.times[x]; return v[0] if v[0] is not None else v[1]
    def dep(s,x): v=s.times[x]; return v[1] if v[1] is not None else v[0]
    def stopped(s,x): return s.times[x][2]
def fmt(t):
    if t is None: return ""
    t=int(round(t)); h=t//3600; m=(t%3600)//60; sec=t%60
    return f"{h}:{m:02d}"+("" if sec==0 else f"½" if sec==30 else f"'{sec:02d}")
def hms(t): t=int(round(t)); return f"{t//3600}:{(t%3600)//60:02d}:{t%60:02d}"

def conflicts(trains, extra_occ=None):
    out=[]
    for tr in trains: tr.compute()
    # 1 複線区間の続行・順序
    segs={}
    for tr in trains:
        r=tr.route
        for a,b in zip(r,r[1:]):
            if single_sec_of(a,b): continue
            segs.setdefault((a,b),[]).append(tr)
    for (a,b),L in segs.items():
        L=sorted(L,key=lambda t:t.dep(a))
        for A,B in zip(L,L[1:]):
            gd=B.dep(a)-A.dep(a); ga=B.arr(b)-A.arr(b)
            if gd<H_DEP or ga<H_ARR:
                out.append(("seg",max(A.dep(a),B.dep(a)),A,B,a,b,max(H_DEP-gd,H_ARR-ga)))
    # 2 駅の在線
    occ={}
    for tr in trains:
        for x,(ar,dp,stp) in tr.times.items():
            if x==tr.o or x==tr.d: continue  # 始終端は別扱い
            key=(x,"*") if x in TOTAL_CAP else (x,tr.dir)
            if x=="学院前": key=(x,tr.dir,"H" if (tr.o in HN[1:] or tr.d in HN[1:]) else "M")
            if stp: iv=(ar,dp+PAD)
            else: iv=(ar-5,ar+PAD)
            occ.setdefault(key,[]).append((iv[0],iv[1],tr))
    if extra_occ:
        for key,ivs in extra_occ.items(): occ.setdefault(key,[]).extend(ivs)
    # 学院前：内側線（蓮木線）と外側線（本線）。本線の列車は外側が埋まっていれば内側を使える
    for dr in ("D","U"):
        Hs=sorted(occ.pop(("学院前",dr,"H"),[]),key=lambda z:z[0])
        Ms=sorted(occ.pop(("学院前",dr,"M"),[]),key=lambda z:z[0])
        for A,B in zip(Hs,Hs[1:]):
            if B[0]<A[1]: out.append(("occ",B[0],B[2],[A[2],B[2]],"学院前",None,0))
        outer_free=-1e9; inner=[(a,b) for a,b,_ in Hs]; inner_extra=[]
        for a,b,tr in Ms:
            if a>=outer_free: outer_free=b; continue
            busy=any(not(b<=x or a>=y) for x,y in inner+inner_extra)
            if not busy: inner_extra.append((a,b)); continue
            cur=[z[2] for z in Ms if z[0]<b and z[1]>a]+[z[2] for z in Hs if z[0]<b and z[1]>a]
            out.append(("occ",a,tr,cur,"学院前",None,0))
    for key,L in occ.items():
        st=key[0]
        cap=TOTAL_CAP.get(st, 2 if st in K2 else 1)
        ev=sorted([(s,1,tr) for s,e,tr in L]+[(e,-1,tr) for s,e,tr in L],key=lambda z:(z[0],z[1]))
        cur=[]
        for t,k,tr in ev:
            if k==1:
                cur.append(tr)
                if len(cur)>cap:
                    out.append(("occ",t,tr,list(cur),st,None,0))
            else:
                if tr in cur: cur.remove(tr)
    # 3 単線区間
    sec={}
    for tr in trains:
        r=tr.route
        for x,y in SINGLE_SEC:
            if x in r and y in r:
                i,j=r.index(x),r.index(y)
                ent,ex=(x,y) if i<j else (y,x)
                sec.setdefault((x,y),[]).append((tr.dep(ent),tr.arr(ex),tr,ent,ex))
            elif (x in r) != (y in r):
                # 区間内に始終端（ありえない設定）
                pass
    for k,L in sec.items():
        L.sort(key=lambda z:z[0])
        for i in range(len(L)):
            for j in range(i+1,len(L)):
                s1,e1,t1,_,_=L[i]; s2,e2,t2,_,_=L[j]
                if s2 < e1+SPAD and s1 < e2+SPAD:
                    out.append(("single",max(s1,s2),t1,t2,k,L[i],L[j]))
    out.sort(key=lambda c:c[1])
    return out

def prev_stop_at_or_before(tr,a,need_cap2=False):
    r=tr.route; i=r.index(a)
    for k in range(i,-1,-1):
        x=r[k]
        if x==tr.d: continue
        if need_cap2:
            if not (x in K2 or TOTAL_CAP.get(x,1)>=2): continue
            if x in ("軒屋","蓮木市","奥雲温泉"): continue
        if tr.stopped(x) and tr.times[x][1] is not None: return x
    return None

def resolve(trains,c,maxwait=420,log=None):
    typ=c[0]
    if typ=="seg":
        _,t,A,B,a,b,deficit=c
        if RANK.get(B.kind,1)>RANK.get(A.kind,1) and deficit>60:
            r=A.route; i=r.index(a); best=None
            for k in range(i,0,-1):
                p=r[k]
                if p not in B.times: break
                if not (p in K2 or TOTAL_CAP.get(p,1)>=2) or p in ("軒屋","蓮木市","奥雲温泉"): continue
                if not A.stopped(p) or A.times[p][1] is None: continue
                if B.arr(p) < A.arr(p)+60: continue
                w=B.dep(p)+H_DEP-A.dep(p)
                if w<=0: continue
                if best is None or w<best[0]: best=(w,p)
            if best and best[0]<=maxwait:
                w,p=best
                A.hold[p]=A.hold.get(p,0)+int(math.ceil(w/15))*15
                if log is not None: log.append(f"待避 {A.id}@{p} +{w:.0f} ← {B.id}")
                return True
        q=prev_stop_at_or_before(B,a)
        if q is None: return False
        add=int(math.ceil(deficit/15))*15
        B.hold[q]=B.hold.get(q,0)+add
        if log is not None: log.append(f"抑止 {B.id}@{q} +{add} (前 {A.id})")
        return True
    if typ=="occ":
        _,t,tr,cur,st,_,_=c
        # 遅く着いた tr を手前で抑える
        others=[x for x in cur if x is not tr]
        need=min(o.dep(st) if o.times[st][1] is not None else o.arr(st) for o in others)+PAD-tr.arr(st)+15
        r=tr.route; i=r.index(st)
        q=prev_stop_at_or_before(tr,r[i-1]) if i>0 else None
        if q is None or need<=0: return False
        add=int(math.ceil(need/15))*15
        tr.hold[q]=tr.hold.get(q,0)+add
        if log is not None: log.append(f"在線 {tr.id}@{q} +{add} ({st})")
        return True
    if typ=="single":
        _,t,t1,t2,k,L1,L2=c
        s1,e1,_,en1,ex1=L1; s2,e2,_,en2,ex2=L2
        w1=e2+SPAD-s1; w2=e1+SPAD-s2   # t1が待つ / t2が待つ
        def cost(tr,w): return w*(2 if tr.kind=="快速" else 1)
        opts=[]
        if w1>0 and en1!=t1.o or w1>0: opts.append((cost(t1,w1),t1,en1,w1))
        if w2>0: opts.append((cost(t2,w2),t2,en2,w2))
        opts.sort(key=lambda z:z[0])
        for _,tr,en,w in opts:
            add=int(math.ceil(w/15))*15
            if en==tr.o: tr.dep0+=add
            else: tr.hold[en]=tr.hold.get(en,0)+add
            if log is not None: log.append(f"交換 {tr.id}@{en} +{add}")
            return True
    return False

def solve(trains,maxit=3000,log=None,maxwait=420,extra=None):
    for it in range(maxit):
        cs=conflicts(trains,extra(trains) if extra else None)
        if not cs: return []
        if not resolve(trains,cs[0],maxwait,log): return cs
    return conflicts(trains)
