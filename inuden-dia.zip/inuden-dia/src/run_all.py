import pickle,sys
from build import *
def add_branch(trains):
    new=[]
    # 蓮木線内の各停：本線各停と学院前で同じホーム乗り換え
    for L in trains:
        if L.kind!="各停" or "学院前" not in L.route or L.o=="学院前" or L.d=="学院前": continue
        if L.d in HN or L.o in HN: continue
        if L.dir=="D":
            dep=L.arr("学院前")+75
            if dep<FIRST: continue
            new.append(mkt("各停","学院前","蓮木市",dep,note="線内"))
        else:
            a=L.arr("学院前")-150
            tr=mkt("各停","蓮木市","学院前",0,note="線内"); tr.compute()
            tr.dep0=a-tr.arr("学院前")
            if tr.dep0>=FIRST: new.append(tr)
    # 奥雲線の各停：毎時1本（犬塚〜奥雲温泉）。下りは快速犬塚行の着後、上りは快速軒屋行（犬塚始発）の発車前
    for R in trains:
        if R.kind!="快速" or "犬塚" not in (R.o,R.d): continue
        if R.dir=="D" and ((R.dep("軒屋")//900)%4)==2:
            dep=R.arr("犬塚")+120
            new.append(mkt("各停","犬塚","奥雲温泉",dep,note="奥雲線"))
        if R.dir=="U" and R.o=="犬塚":
            k=((R.dep("新犬村")-UP_BASE)//900)%4 if R.times else None
            if k==2:
                tr=mkt("各停","奥雲温泉","犬塚",0,note="奥雲線"); tr.compute()
                tr.dep0=R.dep("犬塚")-120-tr.arr("犬塚")
                if tr.dep0>=FIRST: new.append(tr)
    return new
if __name__=="__main__":
    tr=build()
    log=[]
    left,links=solve2(tr,log=log)
    print("main left",len(left))
    for t in tr: t.compute()
    br=add_branch(tr); tr+=br
    left,links=solve2(tr,log=log)
    print("all left",len(left), left[:3])
    l2,stab=link(tr)
    print("stabled",stab)
    pickle.dump((tr,log),open("res.pkl","wb"))
    print(len(log)); print("\n".join(log[-40:]))
