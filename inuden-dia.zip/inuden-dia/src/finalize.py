import pickle,sys,json,math
PKF=sys.argv[1]; sys.argv=[sys.argv[0],PKF]
from morning_run import *
tr,log,placed=pickle.load(open("extras.pkl","rb"))
for t in tr: t.compute()
log=[]
# ---- 増発列車の軒屋到着後：急行2本は軒屋の留置線、残りは就島車庫へ回送
ext=sorted([t for t in tr if getattr(t,"extra",False)],key=lambda t:t.arr("軒屋"))
kyu=[t for t in ext if t.kind=="急行"]
to_yard=kyu[-2:]
for x in to_yard: x.after="軒屋留置線へ"
kaiso=[]
for x in ext:
    if x in to_yard: continue
    best=None
    for d in range(240,2400,30):
        k=Train("","回送","軒屋","就島",x.arr("軒屋")+d); k.frozen=False; k.nolink=True; k.src=x; k.cars=x.cars
        k.label="回送"; k.note="増発車の入庫"
        trial=tr+kaiso+[k]
        left=solve(trial,[],maxit=40,only=[k])
        if not left and sum(k.hold.values())<=300:
            best=k; break
    if best is None: print("回送 FAIL",x.label,x.o); continue
    kaiso.append(best); x.after="就島車庫へ回送"
    print("回送",fmt(best.dep("軒屋")),"→就島",fmt(best.arr("就島")),best.hold)
tr+=kaiso
for i,t in enumerate(tr): t.compute()
cs,links=all_conf2(tr)
print("conflicts",len(cs))
for c in cs[:5]: print(c[0],hms(c[1]),[(x.kind,x.o,x.d,fmt(x.dep(x.o))) for x in involved(c)][:3],c[4])
# ---- 車両の連結（運用）
links,stab=link_nl(tr)
for t in tr:
    if getattr(t,"src",None) is not None: links[t]=t.src
nxt={}
for D,A in links.items():
    if A is not None: nxt[A]=D
heads=[t for t in tr if links.get(t) is None and not (getattr(t,"src",None))]
chains=[]
seen=set()
for h in sorted(heads,key=lambda t:t.dep(t.o)):
    c=[h]; seen.add(h)
    while c[-1] in nxt and nxt[c[-1]] not in seen: c.append(nxt[c[-1]]); seen.add(c[-1])
    chains.append(c)
for t in tr:
    if t not in seen: chains.append([t]); seen.add(t)
# 両数：ラッシュ（軒屋着7:30〜9:00）の上りは優等8両・各停6両。運用の前後もその両数で走る
def rush_cars(t):
    if t.dir=="U" and t.d=="軒屋" and RUSH[0]<=t.arr("軒屋")<=RUSH[1]:
        return 8 if t.kind in ("急行","快速") else 6
    return 0
for c in chains:
    rc=[rush_cars(t) for t in c]
    for i,t in enumerate(c):
        if getattr(t,"extra",False) or t.kind=="回送": continue
        base=4
        # ラッシュ列車より前（送り込み）と、その直後の折返し1本は長い編成のまま
        r=max([rc[j] for j in range(i,len(c))]+[0]) if t.dep(t.o)<T(9,0) else 0
        prev=max(rc[:i]+[0]); 
        if prev and i>0 and rc[i-1] and t.dep(t.o)<T(9,45): r=max(r,rc[i-1])
        t.cars=max(base,r) if r else base
        if t.note in ("線内","奥雲線"): t.cars=4
for i,c in enumerate(chains):
    for t in c: t.unyo=i+1
# ---- 夜間滞泊（始発前に各駅にいる編成）
start={}
for c in chains:
    h=c[0]; st=h.o
    start.setdefault(st,[]).append(h)
print("滞泊",{k:len(v) for k,v in start.items()})
json.dump({"chains":len(chains)},open("meta.json","w"))
pickle.dump((tr,chains,start),open("final.pkl","wb"))
