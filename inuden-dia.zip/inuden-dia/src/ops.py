from sched import *
TERM=["軒屋","新犬村","学院前","蓮木市","就島","高島","秋田台","新狛野","犬塚","奥雲温泉"]
MINTURN={"軒屋":240,"蓮木市":240,"奥雲温泉":180,"学院前":360,"高島":360}
def minturn(x): return MINTURN.get(x,240)
LONG=900  # これより長く待つ編成は留置線・車庫へ
def link(trains):
    """終端駅での折返しの対応づけ。戻り値: links(dep_train->arr_train or None), stabled{駅:数}"""
    for t in trains:
        if t.times is None: t.compute()
    links={}; stabled={}
    for X in set([t.o for t in trains]+[t.d for t in trains]):
        arrs=sorted([t for t in trains if t.d==X],key=lambda t:t.arr(X))
        deps=sorted([t for t in trains if t.o==X],key=lambda t:t.dep(X))
        pool=[]; ai=0
        for D in deps:
            while ai<len(arrs) and arrs[ai].arr(X)+minturn(X)<=D.dep(X):
                pool.append(arrs[ai]); ai+=1
            if pool:
                A=pool.pop(0); links[D]=A
            else:
                links[D]=None; stabled[X]=stabled.get(X,0)+1
    return links,stabled
def turn_occ(trains,links):
    """折返し・滞泊編成の在線（駅の番線）"""
    occ={}
    def add(key,s,e,tr): occ.setdefault(key,[]).append((s,e,tr))
    used=set()
    for D,A in links.items():
        X=D.o
        if A is not None: used.add(A)
        if X in ("軒屋","蓮木市","奥雲温泉"):
            key=(X,"*")
            if A is None: add(key,D.dep(X)-600,D.dep(X)+PAD,D)
            elif D.dep(X)-A.arr(X)<=LONG: add(key,A.arr(X),D.dep(X)+PAD,D)
            else: add(key,A.arr(X),A.arr(X)+180,A); add(key,D.dep(X)-480,D.dep(X)+PAD,D)
            continue
        if X=="学院前":
            if A is not None: add((X,A.dir,"H"),A.arr(X),A.arr(X)+90,A)
            add((X,D.dir,"H"),D.dep(X)-120,D.dep(X)+PAD,D)
            continue
        if X=="高島":
            if A is not None: add((X,A.dir),A.arr(X),A.arr(X)+120,A)
            add((X,D.dir),D.dep(X)-180,D.dep(X)+PAD,D)
            continue
        # 2面4線の折返し（下り側で折り返して上りへ）・車庫
        if A is not None and D.dep(X)-A.arr(X)<=LONG:
            add((X,A.dir),A.arr(X),D.dep(X)+PAD,D)
        else:
            if A is not None: add((X,A.dir),A.arr(X),A.arr(X)+120,A)
            add((X,D.dir),D.dep(X)-240,D.dep(X)+PAD,D)
    for A in trains:
        X=A.d
        if A in used: continue
        if X in ("軒屋","蓮木市","奥雲温泉"): add((X,"*"),A.arr(X),A.arr(X)+180,A)
        elif X=="学院前": add((X,A.dir,"H"),A.arr(X),A.arr(X)+90,A)
        else: add((X,A.dir),A.arr(X),A.arr(X)+120,A)
    return occ
def cross_conf(trains,links):
    """2面4線駅で下り側から上りへ折り返す出発が、本線の列車と交差しないか"""
    out=[]
    for D,A in links.items():
        X=D.o
        if X not in ("就島","秋田台","新狛野","犬塚"): continue
        if A is None or D.dep(X)-A.arr(X)>LONG: continue
        if D.dir!="U": continue
        t0=D.dep(X)
        for T in trains:
            if T is D or T is A or X not in T.times: continue
            if T.o==X or T.d==X: continue
            tt=T.arr(X) if T.dir=="D" else T.dep(X)
            if abs(tt-t0)<60:
                out.append(("cross",t0,D,T,X,None,60-abs(tt-t0)))
    return out
def all_conf(trains):
    for t in trains: t.compute()
    links,_=link(trains)
    cs=conflicts(trains,turn_occ(trains,links))+cross_conf(trains,links)
    cs.sort(key=lambda c:c[1]); return cs,links
def resolve2(trains,c,maxwait,log):
    if c[0]=="cross":
        _,t0,D,T,X,_,need=c
        add=int(math.ceil((need+1)/15))*15
        D.dep0+=add
        if log is not None: log.append(f"折返交差 {D.id}@{X} +{add} ({T.id})")
        return True
    if c[0]=="occ":
        _,t,tr,cur,st,_,_=c
        if st==tr.o:   # 折返し・始発の列車が入れない → 発車を遅らせるのではなく、在線中の通過列車側を見る
            tr.dep0+=60
            if log is not None: log.append(f"始発在線 {tr.id}@{st} +60")
            return True
        if st==tr.d:
            q=prev_stop_at_or_before(tr,tr.route[-2])
            if q: tr.hold[q]=tr.hold.get(q,0)+30; 
            if log is not None: log.append(f"終着在線 {tr.id}@{q} +30 ({st})")
            return True
    return resolve(trains,c,maxwait,log)
def solve2(trains,maxit=4000,maxwait=240,log=None):
    for i in range(maxit):
        cs,links=all_conf(trains)
        if not cs: return [],links
        if not resolve2(trains,cs[0],maxwait,log): return cs,links
    cs,links=all_conf(trains); return cs,links
